package de.kai_morich.simple_usb_terminal;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** APEI mode selector scaffold. AVR programming is not yet integrated. */
public class MainActivity extends AppCompatActivity {
    private final int apeiTeal = Color.rgb(36, 124, 139);
    private final int apeiDark = Color.rgb(25, 87, 98);

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(apeiDark);
        getWindow().setNavigationBarColor(Color.BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(36), dp(24), dp(24));
        root.setBackgroundColor(Color.WHITE);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.apei_logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(-1, dp(118));
        logoLp.bottomMargin = dp(8);
        root.addView(logo, logoLp);

        TextView choose = new TextView(this);
        choose.setText("Scegli la modalità");
        choose.setTextColor(Color.DKGRAY);
        choose.setTextSize(20);
        choose.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        choose.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams chooseLp = new LinearLayout.LayoutParams(-1, dp(72));
        chooseLp.topMargin = dp(28);
        root.addView(choose, chooseLp);

        Button terminal = button("TERMINALE USB", apeiTeal);
        terminal.setOnClickListener(v -> startActivity(new Intent(this, TerminalActivity.class)));
        root.addView(terminal, buttonLp());

        Button avr = button("PROGRAMMAZIONE AVR", apeiDark);
        LinearLayout.LayoutParams avrLp = buttonLp();
        avrLp.topMargin = dp(14);
        root.addView(avr, avrLp);
        avr.setOnClickListener(v -> Toast.makeText(this,
                "Modalità AVR: integrazione in corso. Non ancora disponibile.", Toast.LENGTH_LONG).show());

        TextView note = new TextView(this);
        note.setText("Versione di sviluppo — programmazione AVR non ancora integrata");
        note.setTextColor(Color.GRAY);
        note.setTextSize(12);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT);
        noteLp.topMargin = dp(28);
        root.addView(note, noteLp);
        setContentView(root);
    }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        return b;
    }
    private LinearLayout.LayoutParams buttonLp() {
        return new LinearLayout.LayoutParams(-1, dp(58));
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
